
// FILENAME: src/features/canvas/canvasUtils.ts - VERSION: v11 (Reverted from v12)
// Updated to v10 to change AI summary buttons (remove generate, add regenerate).
// Updated to v11 to add "Edit Mermaid" button for relevant ImageElements.

import {
  WhiteboardElement,
  PathElement,
  TextElement,
  FlowchartShapeElement,
  ImageElement,
  EmojiElement,
  ContentBoxElement, 
  ConnectorElement,
  Point,
  ResizeHandle,
  ResizeHandleType,
  ShapeType,
  LineStyle,
  ElementSummaryActionButton,
} from '../../../types';
import { 
    DEFAULT_FONT_SIZE, DEFAULT_FONT_FAMILY, TRANSPARENT_FILL_VALUE, HANDLE_SIZE, 
    DEFAULT_CONTENT_BOX_FONT_SIZE, MIN_CONTENT_BOX_SIZE,
    CONNECTOR_HANDLE_RADIUS, CONNECTOR_HANDLE_FILL_COLOR, CONNECTOR_HANDLE_STROKE_COLOR, CONNECTOR_HANDLE_STROKE_WIDTH,
    CONNECTOR_SNAP_TARGET_RADIUS, CONNECTOR_SNAP_TARGET_FILL_COLOR, DEFAULT_LINE_STYLE,
    AI_SUMMARY_BUTTON_SIZE, AI_SUMMARY_BUTTON_PADDING, AI_SUMMARY_BUTTON_COLOR, AI_SUMMARY_LOADING_COLOR,
    AI_SUMMARY_TEXT_MAX_WIDTH, AI_SUMMARY_TEXT_PADDING, AI_SUMMARY_TEXT_FONT_SIZE, AI_SUMMARY_TEXT_LINE_HEIGHT,
    AI_SUMMARY_TEXT_COLOR, AI_SUMMARY_BACKGROUND_COLOR, AI_SUMMARY_BORDER_COLOR, AI_SUMMARY_OFFSET_X, AI_SUMMARY_OFFSET_Y, AI_SUMMARY_MARGIN_FROM_BUTTONS
} from '../../../constants';

// Helper to transform virtual coordinates to viewport coordinates for drawing
const toViewportPosUtil = (virtualPos: Point, viewBoxX: number, viewBoxY: number): Point => ({
  x: virtualPos.x - viewBoxX,
  y: virtualPos.y - viewBoxY,
});

// --- AI Summary Icon Drawing Functions ---
const drawRegenerateAISummaryIcon = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number) => {
    ctx.save();
    ctx.strokeStyle = AI_SUMMARY_BUTTON_COLOR;
    ctx.lineWidth = size / 8;
    const s = size * 0.8;
    const centerX = x + size / 2;
    const centerY = y + size / 2;
    const radius = s / 2.5;

    // Circular arrow
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, Math.PI * 0.2, Math.PI * 1.7);
    ctx.stroke();

    // Arrowhead
    const angle = Math.PI * 1.75; // Pointing roughly towards start of arc
    ctx.beginPath();
    ctx.moveTo(centerX + Math.cos(angle) * radius, centerY + Math.sin(angle) * radius);
    ctx.lineTo(centerX + Math.cos(angle - 0.3) * (radius - size*0.1), centerY + Math.sin(angle - 0.3) * (radius - size*0.1));
    ctx.lineTo(centerX + Math.cos(angle + 0.3) * (radius - size*0.1), centerY + Math.sin(angle + 0.3) * (radius - size*0.1));
    ctx.closePath();
    ctx.fillStyle = AI_SUMMARY_BUTTON_COLOR;
    ctx.fill();
    ctx.restore();
};

const drawShowAISummaryIcon = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number) => {
  ctx.save();
  ctx.strokeStyle = AI_SUMMARY_BUTTON_COLOR;
  ctx.lineWidth = size / 8;
  const s = size * 0.8; 
  const offX = x + size * 0.1;
  const offY = y + size * 0.1;
  ctx.beginPath();
  ctx.ellipse(offX + s / 2, offY + s / 2, s / 2, s / 3.5, 0, 0, 2 * Math.PI);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(offX + s / 2, offY + s / 2, s / 6, 0, 2 * Math.PI);
  ctx.fillStyle = AI_SUMMARY_BUTTON_COLOR;
  ctx.fill();
  ctx.restore();
};

const drawHideAISummaryIcon = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number) => {
  drawShowAISummaryIcon(ctx, x, y, size); 
  ctx.save();
  ctx.strokeStyle = AI_SUMMARY_BUTTON_COLOR;
  ctx.lineWidth = size / 7;
  const s = size * 0.9; 
  const offX = x + size * 0.05;
  const offY = y + size * 0.05;
  ctx.beginPath();
  ctx.moveTo(offX, offY + s);
  ctx.lineTo(offX + s, offY);
  ctx.stroke();
  ctx.restore();
};

const drawLoadingAISummaryIcon = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number) => {
  ctx.save();
  ctx.strokeStyle = AI_SUMMARY_LOADING_COLOR;
  ctx.lineWidth = size / 6;
  const s = size * 0.7;
  const offX = x + size * 0.15;
  const offY = y + size * 0.15;
  ctx.beginPath();
  ctx.arc(offX + s / 2, offY + s / 2, s / 2.5, Math.PI * 0.2, Math.PI * 1.2);
  ctx.stroke();
  ctx.restore();
};

const drawEditMermaidIcon = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number) => {
    ctx.save();
    ctx.strokeStyle = AI_SUMMARY_BUTTON_COLOR; // Use same color for consistency
    ctx.lineWidth = size / 9;
    const s = size * 0.75;
    const offX = x + size * 0.125;
    const offY = y + size * 0.125;

    // Simple pencil icon
    ctx.beginPath();
    // Body of pencil
    ctx.moveTo(offX + s * 0.2, offY + s * 0.8);
    ctx.lineTo(offX + s * 0.8, offY + s * 0.2);
    // Tip
    ctx.lineTo(offX + s * 0.65, offY + s * 0.05);
    ctx.lineTo(offX + s * 0.95, offY + s * 0.35);
    ctx.lineTo(offX + s * 0.8, offY + s * 0.2); // Back to join
    
    // Eraser part (optional, simple rectangle)
    ctx.moveTo(offX + s * 0.2, offY + s * 0.8);
    ctx.lineTo(offX + s * 0.1, offY + s * 0.9);
    ctx.lineTo(offX + s * 0.3, offY + s * 1.1); // Exaggerate for visibility
    ctx.lineTo(offX + s * 0.4, offY + s * 1.0);
    ctx.closePath();

    ctx.stroke();
    ctx.restore();
};


export const drawPath = (ctx: CanvasRenderingContext2D, element: PathElement, viewBoxX: number, viewBoxY: number) => {
  ctx.beginPath();
  ctx.strokeStyle = element.color;
  ctx.lineWidth = element.strokeWidth;
  element.points.forEach((point, index) => {
    const vp = toViewportPosUtil(point, viewBoxX, viewBoxY);
    if (index === 0) ctx.moveTo(vp.x, vp.y);
    else ctx.lineTo(vp.x, vp.y);
  });
  if (element.points.length > 0) ctx.stroke();
};

export const drawTextElement = (ctx: CanvasRenderingContext2D, element: TextElement, viewBoxX: number, viewBoxY: number) => {
  const vp = toViewportPosUtil({ x: element.x, y: element.y }, viewBoxX, viewBoxY);
  ctx.fillStyle = element.color;
  ctx.font = element.font;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText(element.text, vp.x, vp.y);
};

export const drawFlowchartShape = (
  ctx: CanvasRenderingContext2D,
  element: FlowchartShapeElement,
  viewBoxX: number,
  viewBoxY: number
) => {
  const vp = toViewportPosUtil({ x: element.x, y: element.y }, viewBoxX, viewBoxY);
  const { width, height, shapeType, fillColor, borderColor, strokeWidth, text, textColor } = element;
  const x = vp.x;
  const y = vp.y;

  ctx.fillStyle = fillColor;
  ctx.strokeStyle = borderColor;
  ctx.lineWidth = strokeWidth;

  if (shapeType !== 'cylinder') {
    ctx.beginPath();
    if (shapeType === 'rectangle') {
      ctx.rect(x, y, width, height);
    } else if (shapeType === 'oval') {
      ctx.ellipse(x + width / 2, y + height / 2, width / 2, height / 2, 0, 0, 2 * Math.PI);
    } else if (shapeType === 'diamond') {
      ctx.moveTo(x + width / 2, y);
      ctx.lineTo(x + width, y + height / 2);
      ctx.lineTo(x + width / 2, y + height);
      ctx.lineTo(x, y + height / 2);
      ctx.closePath();
    } else if (shapeType === 'triangle') {
      ctx.moveTo(x + width / 2, y);
      ctx.lineTo(x + width, y + height);
      ctx.lineTo(x, y + height);
      ctx.closePath();
    } else if (shapeType === 'parallelogram') {
      const skew = width * 0.20;
      ctx.moveTo(x + skew, y);
      ctx.lineTo(x + width, y);
      ctx.lineTo(x + width - skew, y + height);
      ctx.lineTo(x, y + height);
      ctx.closePath();
    } else if (shapeType === 'hexagon') {
      const side = height / 2;
      ctx.moveTo(x + width * 0.25, y);
      ctx.lineTo(x + width * 0.75, y);
      ctx.lineTo(x + width, y + side);
      ctx.lineTo(x + width * 0.75, y + height);
      ctx.lineTo(x + width * 0.25, y + height);
      ctx.lineTo(x, y + side);
      ctx.closePath();
    } else if (shapeType === 'cloud') {
      const r1 = Math.min(width, height) * 0.3;
      const r2 = Math.min(width, height) * 0.25;
      const r3 = Math.min(width, height) * 0.35;
      ctx.arc(x + width * 0.3, y + height * 0.4, r1, Math.PI * 0.8, Math.PI * 1.9);
      ctx.arc(x + width * 0.6, y + height * 0.3, r2, Math.PI * 1.2, Math.PI * 0.2);
      ctx.arc(x + width * 0.7, y + height * 0.65, r3, Math.PI * 1.7, Math.PI * 0.7);
      ctx.arc(x + width * 0.4, y + height * 0.75, r1, Math.PI * 0.2, Math.PI * 1.1);
      ctx.closePath();
    } else if (shapeType === 'star') {
      const outerRadius = Math.min(width, height) / 2;
      const innerRadius = outerRadius / 2.5;
      const centerX = x + width / 2;
      const centerY = y + height / 2;
      let rot = Math.PI / 2 * 3;

      ctx.moveTo(centerX, centerY - outerRadius);
      for (let i = 0; i < 5; i++) {
        ctx.lineTo(centerX + Math.cos(rot) * outerRadius, centerY + Math.sin(rot) * outerRadius);
        rot += Math.PI / 5;
        ctx.lineTo(centerX + Math.cos(rot) * innerRadius, centerY + Math.sin(rot) * innerRadius);
        rot += Math.PI / 5;
      }
      ctx.closePath();
    }

    if (fillColor !== TRANSPARENT_FILL_VALUE) {
      ctx.fill();
    }
    ctx.stroke();
  } else { 
    const capHeight = Math.min(height * 0.2, width / 4, 20);
    ctx.beginPath();
    ctx.ellipse(x + width / 2, y + capHeight, width / 2, capHeight, 0, 0, 2 * Math.PI);
    if (fillColor !== TRANSPARENT_FILL_VALUE) ctx.fill();
    ctx.stroke();
    if (fillColor !== TRANSPARENT_FILL_VALUE) {
      ctx.beginPath();
      ctx.rect(x, y + capHeight, width, height - 2 * capHeight);
      ctx.fill();
    }
    ctx.beginPath();
    ctx.ellipse(x + width / 2, y + height - capHeight, width / 2, capHeight, 0, 0, Math.PI);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y + capHeight);
    ctx.lineTo(x, y + height - capHeight);
    ctx.moveTo(x + width, y + capHeight);
    ctx.lineTo(x + width, y + height - capHeight);
    ctx.stroke();
  }

  if (text) {
    ctx.fillStyle = textColor;
    ctx.font = `${DEFAULT_FONT_SIZE}px ${DEFAULT_FONT_FAMILY}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const lines = [];
    const words = text.split(' ');
    let currentLine = '';
    const maxWidth = width - 10;
    for (const word of words) {
      const testLine = currentLine ? currentLine + ' ' + word : word;
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && currentLine !== '') {
        lines.push(currentLine);
        currentLine = word;
      } else { currentLine = testLine; }
    }
    lines.push(currentLine);
    const lineHeight = DEFAULT_FONT_SIZE * 1.2;
    const totalTextHeight = lines.length * lineHeight;
    let startTextY = y + height / 2 - totalTextHeight / 2 + lineHeight / 2;
    const maxHeight = height - 10;
    if (totalTextHeight > maxHeight) startTextY = y + 5 + lineHeight / 2;
    for (let i = 0; i < lines.length; i++) {
      if ((i * lineHeight) + (lineHeight / 2) > maxHeight && lines.length > 1) break;
      ctx.fillText(lines[i], x + width / 2, startTextY + i * lineHeight);
    }
  }
};

export const drawConnector = (ctx: CanvasRenderingContext2D, element: ConnectorElement, viewBoxX: number, viewBoxY: number) => {
  const vpStart = toViewportPosUtil(element.startPoint, viewBoxX, viewBoxY);
  const vpEnd = toViewportPosUtil(element.endPoint, viewBoxX, viewBoxY);
  const { color, strokeWidth, lineStyle = DEFAULT_LINE_STYLE } = element;
  
  ctx.beginPath();
  ctx.strokeStyle = color;
  ctx.lineWidth = strokeWidth;

  if (lineStyle === 'dotted') {
    const dashLength = Math.max(2, strokeWidth * 1.5);
    const gapLength = Math.max(2, strokeWidth * 1.5);
    ctx.setLineDash([dashLength, gapLength]);
  }

  ctx.moveTo(vpStart.x, vpStart.y);
  ctx.lineTo(vpEnd.x, vpEnd.y);
  ctx.stroke();

  if (lineStyle === 'dotted') {
    ctx.setLineDash([]); 
  }

  if (lineStyle === 'arrow') { 
    const angle = Math.atan2(vpEnd.y - vpStart.y, vpEnd.x - vpStart.x);
    const headLength = Math.min(15, strokeWidth * 3 + 5);
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(vpEnd.x, vpEnd.y);
    ctx.lineTo(vpEnd.x - headLength * Math.cos(angle - Math.PI / 6), vpEnd.y - headLength * Math.sin(angle - Math.PI / 6));
    ctx.lineTo(vpEnd.x - headLength * Math.cos(angle + Math.PI / 6), vpEnd.y - headLength * Math.sin(angle + Math.PI / 6));
    ctx.closePath();
    ctx.fill();
  }
};

export const drawImageElement = (
  ctx: CanvasRenderingContext2D,
  element: ImageElement,
  imageObject: HTMLImageElement | undefined,
  viewBoxX: number,
  viewBoxY: number
) => {
  const vp = toViewportPosUtil({ x: element.x, y: element.y }, viewBoxX, viewBoxY);
  if (imageObject && imageObject.complete) {
    ctx.drawImage(imageObject, vp.x, vp.y, element.width, element.height);
  } else {
    ctx.fillStyle = '#f0f0f0';
    ctx.fillRect(vp.x, vp.y, element.width, element.height);
    ctx.strokeStyle = '#cccccc';
    ctx.strokeRect(vp.x, vp.y, element.width, element.height);
    ctx.fillStyle = '#999999';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '12px Arial';
    const isSvg = element.src.startsWith('data:image/svg+xml');
    const placeholderText = imageObject ? (isSvg ? 'Rendering...' : 'Loading...') : 'Error';
    ctx.fillText(placeholderText, vp.x + element.width / 2, vp.y + element.height / 2);
  }
};

export const drawEmojiElement = (ctx: CanvasRenderingContext2D, element: EmojiElement, viewBoxX: number, viewBoxY: number) => {
  const vp = toViewportPosUtil({ x: element.x, y: element.y }, viewBoxX, viewBoxY);
  ctx.font = `${element.size}px ${DEFAULT_FONT_FAMILY}`;
  ctx.fillStyle = 'black'; 
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText(element.emojiChar, vp.x, vp.y);
};

export const drawContentBoxElement = (ctx: CanvasRenderingContext2D, element: ContentBoxElement, viewBoxX: number, viewBoxY: number) => {
  const vp = toViewportPosUtil({ x: element.x, y: element.y }, viewBoxX, viewBoxY);
  const { width, height, backgroundColor, textColor, fontSize, content, filename, contentType } = element;
  
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(vp.x, vp.y, width, height);
  ctx.strokeStyle = '#A0AEC0'; 
  ctx.lineWidth = 1;
  ctx.strokeRect(vp.x, vp.y, width, height);

  const headerHeight = 24;
  const headerPadding = 5;
  ctx.fillStyle = '#E2E8F0'; 
  ctx.fillRect(vp.x, vp.y, width, headerHeight);
  ctx.strokeStyle = '#CBD5E0'; 
  ctx.strokeRect(vp.x, vp.y, width, headerHeight);
  
  ctx.fillStyle = '#4A5568'; 
  ctx.font = `bold 12px ${DEFAULT_FONT_FAMILY}`;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  const headerText = filename ? `${filename} (${contentType})` : contentType;
  ctx.fillText(headerText, vp.x + headerPadding, vp.y + headerHeight / 2, width - headerPadding * 2);

  ctx.fillStyle = textColor;
  ctx.font = `${fontSize}px ${contentType === 'javascript' || contentType === 'python' || contentType === 'json' ? 'monospace' : DEFAULT_FONT_FAMILY}`;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';

  const contentPadding = 8;
  const contentStartX = vp.x + contentPadding;
  const contentStartY = vp.y + headerHeight + contentPadding;
  const maxContentWidth = width - contentPadding * 2;
  const maxContentHeight = height - headerHeight - contentPadding * 2;
  
  if (maxContentWidth <= 0 || maxContentHeight <= 0) return;

  const lines = content.split('\n');
  let currentY = contentStartY;
  const lineHeight = fontSize * 1.3;

  ctx.save();
  ctx.beginPath();
  ctx.rect(contentStartX, contentStartY, maxContentWidth, maxContentHeight);
  ctx.clip();

  for (const line of lines) {
    if (currentY + lineHeight > contentStartY + maxContentHeight + fontSize * 0.3) { 
        if (currentY <= contentStartY + maxContentHeight - lineHeight) { 
             const lastVisibleLineY = currentY - lineHeight;
             ctx.fillText("...", contentStartX, lastVisibleLineY, maxContentWidth);
        }
        break;
    }
    
    let currentLineText = line;
    let textMetrics = ctx.measureText(currentLineText);
    
    if (textMetrics.width > maxContentWidth) {
        let words = line.split(' ');
        let wrappedLine = '';
        for (let i = 0; i < words.length; i++) {
            let testLine = wrappedLine + words[i] + ' ';
            if (ctx.measureText(testLine).width > maxContentWidth && i > 0) {
                ctx.fillText(wrappedLine, contentStartX, currentY, maxContentWidth);
                currentY += lineHeight;
                if (currentY + lineHeight > contentStartY + maxContentHeight + fontSize * 0.3) break;
                wrappedLine = words[i] + ' ';
            } else {
                wrappedLine = testLine;
            }
        }
        currentLineText = wrappedLine.trim();
    }

    if (currentY + lineHeight <= contentStartY + maxContentHeight + fontSize * 0.3) {
       ctx.fillText(currentLineText, contentStartX, currentY, maxContentWidth);
    }
    currentY += lineHeight;
  }
  ctx.restore(); 
};

export const getElementBoundingBox = (
  element: WhiteboardElement,
  ctxForTextMeasurement: CanvasRenderingContext2D | null
): { x: number; y: number; width: number; height: number } | null => {
  switch (element.type) {
    case 'flowchart-shape':
    case 'image':
    case 'content-box': 
      return { x: element.x, y: element.y, width: element.width, height: element.height };

    case 'path': {
      if (element.points.length === 0) return { x: 0, y: 0, width: 0, height: 0 };
      let minX = element.points[0].x;
      let minY = element.points[0].y;
      let maxX = element.points[0].x;
      let maxY = element.points[0].y;
      element.points.forEach(p => {
        minX = Math.min(minX, p.x);
        minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x);
        maxY = Math.max(maxY, p.y);
      });
      const padding = element.strokeWidth / 2 + 2;
      return {
        x: minX - padding,
        y: minY - padding,
        width: (maxX - minX) + element.strokeWidth + 4,
        height: (maxY - minY) + element.strokeWidth + 4,
      };
    }

    case 'connector': {
      const minX = Math.min(element.startPoint.x, element.endPoint.x);
      const minY = Math.min(element.startPoint.y, element.endPoint.y);
      const maxX = Math.max(element.startPoint.x, element.endPoint.x);
      const maxY = Math.max(element.startPoint.y, element.endPoint.y);
      const padding = element.strokeWidth / 2 + 5;
      return {
        x: minX - padding,
        y: minY - padding,
        width: (maxX - minX) + element.strokeWidth + 10,
        height: (maxY - minY) + element.strokeWidth + 10,
      };
    }

    case 'text': {
      if (!ctxForTextMeasurement) return null; 
      ctxForTextMeasurement.font = element.font;
      const metrics = ctxForTextMeasurement.measureText(element.text);
      const fontHeightMetrics = ctxForTextMeasurement.measureText('M'); 
      const actualBoundingBoxAscent = fontHeightMetrics.actualBoundingBoxAscent || parseFloat(element.font) || DEFAULT_FONT_SIZE;
      const actualBoundingBoxDescent = fontHeightMetrics.actualBoundingBoxDescent || 0;
      const fontHeight = actualBoundingBoxAscent + actualBoundingBoxDescent;
      return {
        x: element.x,
        y: element.y,
        width: metrics.width,
        height: fontHeight > 0 ? fontHeight : parseFloat(element.font) || DEFAULT_FONT_SIZE, 
      };
    }

    case 'emoji': {
      if (!ctxForTextMeasurement) return null; 
      ctxForTextMeasurement.font = `${element.size}px ${DEFAULT_FONT_FAMILY}`;
      const metrics = ctxForTextMeasurement.measureText(element.emojiChar);
      const capitalM_metrics = ctxForTextMeasurement.measureText('M'); 
      const ascent = capitalM_metrics.actualBoundingBoxAscent || element.size * 0.75; 
      const descent = capitalM_metrics.actualBoundingBoxDescent || element.size * 0.25; 
      const height = ascent + descent;
      return {
        x: element.x,
        y: element.y,
        width: metrics.width,
        height: height,
      };
    }
    default:
      const _exhaustiveCheck: never = element;
      return null;
  }
};

export const isPointInElement = (
  virtualPoint: Point,
  element: WhiteboardElement,
  ctxForTextMeasurement: CanvasRenderingContext2D | null
): boolean => {
  const bbox = getElementBoundingBox(element, ctxForTextMeasurement);
  if (!bbox) return false;

  const clickPadding = 5; 
  if (element.type === 'flowchart-shape' || element.type === 'text' || element.type === 'image' || element.type === 'emoji' || element.type === 'content-box') {
    return virtualPoint.x >= bbox.x - clickPadding && virtualPoint.x <= bbox.x + bbox.width + clickPadding &&
           virtualPoint.y >= bbox.y - clickPadding && virtualPoint.y <= bbox.y + bbox.height + clickPadding;
  }
  
  return virtualPoint.x >= bbox.x && virtualPoint.x <= bbox.x + bbox.width &&
         virtualPoint.y >= bbox.y && virtualPoint.y <= bbox.y + bbox.height;
};

export const getResizeHandles = (
  element: FlowchartShapeElement | EmojiElement | ImageElement | ContentBoxElement, 
  ctxForBBox: CanvasRenderingContext2D | null,
  viewBoxX: number,
  viewBoxY: number
): ResizeHandle[] => {
  const bbox = getElementBoundingBox(element, ctxForBBox);
  if (!bbox) return [];
  const vpBBox = {
    x: bbox.x - viewBoxX,
    y: bbox.y - viewBoxY,
    width: bbox.width,
    height: bbox.height,
  };
  const { x, y, width, height } = vpBBox;
  const hs = HANDLE_SIZE / 2;
  return [
    { type: 'nw', x: x - hs, y: y - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'nwse-resize' },
    { type: 'n', x: x + width / 2 - hs, y: y - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'ns-resize' },
    { type: 'ne', x: x + width - hs, y: y - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'nesw-resize' },
    { type: 'w', x: x - hs, y: y + height / 2 - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'ew-resize' },
    { type: 'e', x: x + width - hs, y: y + height / 2 - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'ew-resize' },
    { type: 'sw', x: x - hs, y: y + height - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'nesw-resize' },
    { type: 's', x: x + width / 2 - hs, y: y + height - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'ns-resize' },
    { type: 'se', x: x + width - hs, y: y + height - hs, width: HANDLE_SIZE, height: HANDLE_SIZE, cursor: 'nwse-resize' },
  ];
};

export const drawResizeHandlesForElement = (
  ctx: CanvasRenderingContext2D,
  element: FlowchartShapeElement | EmojiElement | ImageElement | ContentBoxElement, 
  viewBoxX: number,
  viewBoxY: number
) => {
  const handles = getResizeHandles(element, ctx, viewBoxX, viewBoxY);
  ctx.strokeStyle = '#3B82F6'; 
  ctx.fillStyle = '#FFFFFF';
  ctx.lineWidth = 1;
  handles.forEach(handle => {
    ctx.fillRect(handle.x, handle.y, handle.width, handle.height);
    ctx.strokeRect(handle.x, handle.y, handle.width, handle.height);
  });
};

export const drawSelectionOutline = (
  ctx: CanvasRenderingContext2D,
  element: WhiteboardElement,
  viewBoxX: number,
  viewBoxY: number
) => {
    const bbox = getElementBoundingBox(element, ctx);
    if (!bbox) return;

    const vpBbox = toViewportPosUtil(bbox, viewBoxX, viewBoxY);
    ctx.strokeStyle = '#3B82F6'; 
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);

    if (element.type === 'text') {
        ctx.strokeRect(vpBbox.x - 2, vpBbox.y - 2, bbox.width + 4, bbox.height + 4);
    } else if (element.type === 'path') {
        ctx.strokeRect(vpBbox.x, vpBbox.y, bbox.width, bbox.height);
    } else if (element.type === 'connector') {
        ctx.fillStyle = '#3B82F6';
        const circleRadius = 4;
        const vpStart = toViewportPosUtil(element.startPoint, viewBoxX, viewBoxY);
        const vpEnd = toViewportPosUtil(element.endPoint, viewBoxX, viewBoxY);
        ctx.beginPath();
        ctx.arc(vpStart.x, vpStart.y, circleRadius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(vpEnd.x, vpEnd.y, circleRadius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(vpStart.x, vpStart.y);
        ctx.lineTo(vpEnd.x, vpEnd.y);
        ctx.stroke();
    } else if (element.type === 'flowchart-shape' || element.type === 'emoji' || element.type === 'image' || element.type === 'content-box') {
        ctx.strokeRect(vpBbox.x, vpBbox.y, bbox.width, bbox.height);
    }
    ctx.setLineDash([]);
};

export const getHandleAtPoint = (
  virtualPoint: Point,
  element: FlowchartShapeElement | EmojiElement | ImageElement | ContentBoxElement, 
  ctxForBBox: CanvasRenderingContext2D | null,
  viewBoxX: number,
  viewBoxY: number
): ResizeHandleType | null => {
  const handles = getResizeHandles(element, ctxForBBox, viewBoxX, viewBoxY);
  const viewportPoint = toViewportPosUtil(virtualPoint, viewBoxX, viewBoxY);
  for (const handle of handles) {
    if (viewportPoint.x >= handle.x && viewportPoint.x <= handle.x + handle.width &&
        viewportPoint.y >= handle.y && viewportPoint.y <= handle.y + handle.height) {
      return handle.type;
    }
  }
  return null;
};

export const getConnectorAttachmentPoints = (element: WhiteboardElement): Array<{ point: Point; index: number }> => {
  if (element.type === 'flowchart-shape' || element.type === 'content-box' || element.type === 'image') {
    const { x, y, width, height } = element; 
    return [
      { point: { x: x + width / 2, y: y }, index: 0 },             
      { point: { x: x + width, y: y + height / 2 }, index: 1 },   
      { point: { x: x + width / 2, y: y + height }, index: 2 },   
      { point: { x: x, y: y + height / 2 }, index: 3 },           
    ];
  }
  return [];
};

export const drawConnectorHandles = (
  ctx: CanvasRenderingContext2D,
  element: WhiteboardElement,
  viewBoxX: number,
  viewBoxY: number
) => {
  const attachmentPointsWithIndices = getConnectorAttachmentPoints(element);
  if (attachmentPointsWithIndices.length === 0) {
    return;
  }

  attachmentPointsWithIndices.forEach(item => {
    const vp = toViewportPosUtil(item.point, viewBoxX, viewBoxY);
    ctx.beginPath();
    ctx.arc(vp.x, vp.y, CONNECTOR_HANDLE_RADIUS, 0, 2 * Math.PI);
    ctx.fillStyle = CONNECTOR_HANDLE_FILL_COLOR;
    ctx.fill();
    ctx.strokeStyle = CONNECTOR_HANDLE_STROKE_COLOR;
    ctx.lineWidth = CONNECTOR_HANDLE_STROKE_WIDTH;
    ctx.stroke();
  });
};

export const drawSnapTargetHighlight = (
  ctx: CanvasRenderingContext2D,
  targetVirtualPoint: Point, 
  viewBoxX: number,
  viewBoxY: number
) => {
  const vp = toViewportPosUtil(targetVirtualPoint, viewBoxX, viewBoxY);
  ctx.beginPath();
  ctx.arc(vp.x, vp.y, CONNECTOR_SNAP_TARGET_RADIUS, 0, 2 * Math.PI);
  ctx.fillStyle = CONNECTOR_SNAP_TARGET_FILL_COLOR;
  ctx.fill();
};

// --- AI Summary UI Drawing ---
export const getElementSummaryActionButtons = (
    element: WhiteboardElement,
    viewBoxX: number,
    viewBoxY: number,
    ctxForBBox: CanvasRenderingContext2D | null
): ElementSummaryActionButton[] => {
    if (element.type === 'connector') return [];

    const bbox = getElementBoundingBox(element, ctxForBBox);
    if (!bbox) return [];

    const vpBbox = toViewportPosUtil(bbox, viewBoxX, viewBoxY);
    let currentButtonX = vpBbox.x + bbox.width - AI_SUMMARY_BUTTON_SIZE - AI_SUMMARY_BUTTON_PADDING;
    const buttonY = vpBbox.y + AI_SUMMARY_BUTTON_PADDING;
    
    const buttons: ElementSummaryActionButton[] = [];

    // Add "Edit Mermaid" button if applicable
    if (element.type === 'image' && element.mermaidSyntax) {
        buttons.push({
            type: 'editMermaid',
            x: currentButtonX, y: buttonY, width: AI_SUMMARY_BUTTON_SIZE, height: AI_SUMMARY_BUTTON_SIZE,
            icon: drawEditMermaidIcon 
        });
        currentButtonX -= (AI_SUMMARY_BUTTON_SIZE + AI_SUMMARY_BUTTON_PADDING);
    }


    if (element.aiSummaryLoading) {
        buttons.push({
            type: 'loadingSummary',
            x: currentButtonX, y: buttonY, width: AI_SUMMARY_BUTTON_SIZE, height: AI_SUMMARY_BUTTON_SIZE,
            icon: drawLoadingAISummaryIcon
        });
    } else {
        // Regenerate/Generate button
        buttons.push({
            type: 'regenerateSummary',
            x: currentButtonX, y: buttonY, width: AI_SUMMARY_BUTTON_SIZE, height: AI_SUMMARY_BUTTON_SIZE,
            icon: drawRegenerateAISummaryIcon
        });
        currentButtonX -= (AI_SUMMARY_BUTTON_SIZE + AI_SUMMARY_BUTTON_PADDING); 

        // Show/Hide button (if summary exists)
        if (element.aiSummary && element.aiSummary.trim() !== "" && !element.aiSummary.startsWith("Error:")) {
            buttons.push({
                type: element.aiSummaryVisible ? 'hideSummary' : 'showSummary',
                x: currentButtonX, y: buttonY, width: AI_SUMMARY_BUTTON_SIZE, height: AI_SUMMARY_BUTTON_SIZE,
                icon: element.aiSummaryVisible ? drawHideAISummaryIcon : drawShowAISummaryIcon
            });
        }
    }
    return buttons;
};

export const drawElementActionButtons = (
  ctx: CanvasRenderingContext2D,
  element: WhiteboardElement,
  viewBoxX: number,
  viewBoxY: number
) => {
  const buttons = getElementSummaryActionButtons(element, viewBoxX, viewBoxY, ctx);
  buttons.forEach(button => {
    button.icon(ctx, button.x, button.y, AI_SUMMARY_BUTTON_SIZE);
  });
};

export const drawAISummaryText = (
  ctx: CanvasRenderingContext2D,
  element: WhiteboardElement,
  viewBoxX: number,
  viewBoxY: number
) => {
  if (element.type === 'connector' || !element.aiSummary || !element.aiSummaryVisible) {
    return;
  }

  const bbox = getElementBoundingBox(element, ctx);
  if (!bbox) return;

  const vpBbox = toViewportPosUtil(bbox, viewBoxX, viewBoxY);

  const numberOfButtons = getElementSummaryActionButtons(element, viewBoxX, viewBoxY, ctx).length;
  const totalButtonWidth = numberOfButtons * AI_SUMMARY_BUTTON_SIZE + (numberOfButtons > 0 ? (numberOfButtons -1) * AI_SUMMARY_BUTTON_PADDING : 0);

  let summaryX = vpBbox.x + AI_SUMMARY_OFFSET_X;
  const buttonRowHeight = AI_SUMMARY_BUTTON_SIZE + AI_SUMMARY_BUTTON_PADDING * 2; 
  let summaryY = vpBbox.y + bbox.height + AI_SUMMARY_OFFSET_Y + AI_SUMMARY_MARGIN_FROM_BUTTONS;
  
  summaryY = vpBbox.y + bbox.height + AI_SUMMARY_OFFSET_Y + (totalButtonWidth > 0 ? buttonRowHeight/3 : 0);


  ctx.font = `${AI_SUMMARY_TEXT_FONT_SIZE}px ${DEFAULT_FONT_FAMILY}`;
  const lines = [];
  const words = element.aiSummary.split(' ');
  let currentLine = '';

  for (const word of words) {
    const testLine = currentLine + (currentLine ? ' ' : '') + word;
    const metrics = ctx.measureText(testLine);
    if (metrics.width > AI_SUMMARY_TEXT_MAX_WIDTH && currentLine !== '') {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  lines.push(currentLine);

  const lineHeight = AI_SUMMARY_TEXT_FONT_SIZE * AI_SUMMARY_TEXT_LINE_HEIGHT;
  const summaryHeight = lines.length * lineHeight + AI_SUMMARY_TEXT_PADDING * 2;
  const summaryWidth = Math.min(
    AI_SUMMARY_TEXT_MAX_WIDTH + AI_SUMMARY_TEXT_PADDING * 2,
    Math.max(...lines.map(line => ctx.measureText(line).width)) + AI_SUMMARY_TEXT_PADDING * 2
  );
  
  if (summaryX + summaryWidth > ctx.canvas.width) {
    summaryX = ctx.canvas.width - summaryWidth - AI_SUMMARY_OFFSET_X;
  }
  if (summaryY + summaryHeight > ctx.canvas.height) {
    summaryY = vpBbox.y - summaryHeight - AI_SUMMARY_OFFSET_Y - (totalButtonWidth > 0 ? buttonRowHeight/3 : 0);
  }
  summaryX = Math.max(AI_SUMMARY_OFFSET_X, summaryX);
  summaryY = Math.max(AI_SUMMARY_OFFSET_Y, summaryY);


  ctx.fillStyle = AI_SUMMARY_BACKGROUND_COLOR;
  ctx.strokeStyle = AI_SUMMARY_BORDER_COLOR;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.rect(summaryX, summaryY, summaryWidth, summaryHeight);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = AI_SUMMARY_TEXT_COLOR;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  lines.forEach((line, index) => {
    ctx.fillText(line, summaryX + AI_SUMMARY_TEXT_PADDING, summaryY + AI_SUMMARY_TEXT_PADDING + index * lineHeight);
  });
};

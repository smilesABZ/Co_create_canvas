
// FILENAME: src/features/fileOperations/useFileOperations.ts - VERSION: v16
// Updated to v17 to include Gemini response content boxes as 'prompt_cards' in the Model Card ZIP.
// Updated to v18 to add saveSession functionality and isSessionSaving state.
// Updated to v19 to fix .ccc session file loading and update file extension checks.

import { useState, useRef, useCallback } from 'react';
import { WhiteboardElement, ImageElement, GeminiResponse, ContentBoxElement, ContentType, Tool, AiPersona } from '../../../types';
import { ElementManagerHook } from '../elementManager/useElementManager';
import { CanvasViewHook } from '../canvasView/useCanvasView';
import { interactWithGemini } from '../gemini/geminiService'; 
import { GeminiHook } from '../gemini/useGemini'; 
// TextInputOverlay removed as it's unused
import { DEFAULT_SESSION_NAME, SUPPORTED_TEXT_IMPORT_EXTENSIONS, ALL_SUPPORTED_IMPORT_EXTENSIONS, DEFAULT_CONTENT_BOX_WIDTH, DEFAULT_CONTENT_BOX_HEIGHT, DEFAULT_CONTENT_BOX_BACKGROUND_COLOR, DEFAULT_CONTENT_BOX_TEXT_COLOR, DEFAULT_CONTENT_BOX_FONT_SIZE, SESSION_FILE_EXTENSION } from '../../../constants';

declare var JSZip: any; 

interface UseFileOperationsProps {
  elementManager: ElementManagerHook;
  canvasView: CanvasViewHook;
  geminiHook: GeminiHook; 
  getCanvasImageBase64: () => string | null;
  getFullAppScreenshotBase64?: () => Promise<string | null>;
  canvasRenderWidth: number;
  canvasRenderHeight: number;
  setCurrentTool: (tool: Tool) => void;
  setSelectedElementId: (id: string | null) => void;
}

export interface FileOperationsHook {
  saveCanvasAsImage: () => void;
  saveModelCard: () => Promise<void>;
  saveBriefcaseAsZip: () => Promise<void>;
  triggerImageImport: () => void;
  fileInputRef: React.RefObject<HTMLInputElement>;
  handleFileSelected: (event: React.ChangeEvent<HTMLInputElement>) => void;
  acceptedFileTypes: string;
  isModelCardGenerating: boolean;
  isBriefcaseSaving: boolean;
  saveSession: () => Promise<void>; 
  isSessionSaving: boolean; 
}
const generateSafeFilename = (name: string, extension: string): string => {
  const date = new Date();
  const timestamp = `${date.getFullYear()}${(date.getMonth() + 1).toString().padStart(2, '0')}${date.getDate().toString().padStart(2, '0')}_${date.getHours().toString().padStart(2, '0')}${date.getMinutes().toString().padStart(2, '0')}${date.getSeconds().toString().padStart(2, '0')}`;
  const safeName = name.replace(/[^a-zA-Z0-9_-\s]/g, '').replace(/\s+/g, '_');
  return `${safeName}_${timestamp}.${extension.startsWith('.') ? extension.substring(1) : extension}`;
};


export const useFileOperations = ({
  elementManager,
  canvasView,
  geminiHook, 
  getCanvasImageBase64,
  getFullAppScreenshotBase64,
  canvasRenderWidth,
  canvasRenderHeight,
  setCurrentTool,
  setSelectedElementId,
}: UseFileOperationsProps): FileOperationsHook => {
  const { elements, addElement, sessionName, setElements, onSessionNameChange, clearCanvasElements } = elementManager; 
  const { viewBoxX, viewBoxY, setViewBox } = canvasView; 
  const [isModelCardGenerating, setIsModelCardGenerating] = useState(false);
  const [isBriefcaseSaving, setIsBriefcaseSaving] = useState(false);
  const [isSessionSaving, setIsSessionSaving] = useState(false); 


  const fileInputRef = useRef<HTMLInputElement>(null);
  const acceptedFileTypes = ALL_SUPPORTED_IMPORT_EXTENSIONS;


  const saveCanvasAsImage = useCallback(() => {
    const imageBase64 = getCanvasImageBase64();
    if (imageBase64) {
      const link = document.createElement('a');
      link.download = generateSafeFilename(sessionName || DEFAULT_SESSION_NAME, 'png');
      link.href = `data:image/png;base64,${imageBase64}`;
      link.click();
    } else {
      alert("Could not save canvas image. Canvas might be empty or an error occurred.");
    }
  }, [getCanvasImageBase64, sessionName]);

  const saveModelCard = useCallback(async () => {
    setIsModelCardGenerating(true);
    const imageBase64 = getCanvasImageBase64();
    const fullAppScreenshotBase64 = getFullAppScreenshotBase64 ? await getFullAppScreenshotBase64() : null;

    if (!imageBase64) {
      alert("Could not generate model card. Canvas image is unavailable.");
      setIsModelCardGenerating(false);
      return;
    }

    let analysisText = "AI analysis not performed for this model card.";
    try {
      const analysisPrompt = `Generate a concise model card summary for a digital whiteboard session. Based on the provided image, describe the key visual elements, potential topics, and overall nature of the content. The canvas size is ${canvasRenderWidth}x${canvasRenderHeight} pixels.`;
      const geminiResult = await interactWithGemini(imageBase64, analysisPrompt, canvasRenderWidth, canvasRenderHeight, 'helpful-assistant');
      if (geminiResult.analysisText) {
        analysisText = geminiResult.analysisText;
      } else if (geminiResult.error) {
        analysisText = `Error during AI analysis: ${geminiResult.error}`;
      }
    } catch (error: any) {
      analysisText = `Error performing AI analysis: ${error.message}`;
    }

    const modelCardHTML = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Model Card: ${sessionName || DEFAULT_SESSION_NAME}</title>
        <style>
          body { font-family: sans-serif; margin: 20px; line-height: 1.6; background-color: #f4f4f4; color: #333; }
          .container { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
          h1, h2 { color: #333; border-bottom: 1px solid #eee; padding-bottom: 10px;}
          img { max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 4px; margin-bottom:15px;}
          .section { margin-bottom: 20px; }
          .section h2 { margin-top: 0; }
          pre { background-color: #eee; padding: 10px; border-radius: 4px; white-space: pre-wrap; word-wrap: break-word; }
          ul { padding-left: 20px; }
          li { margin-bottom: 5px; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>Model Card: ${sessionName || DEFAULT_SESSION_NAME}</h1>
          <div class="section">
            <h2>Whiteboard Content Analysis</h2>
            <pre>${analysisText}</pre>
          </div>
          <div class="section">
            <h2>Canvas Image</h2>
            <img src="canvas_image.png" alt="Whiteboard Canvas Image">
          </div>
          ${fullAppScreenshotBase64 ? `
          <div class="section">
            <h2>Full Application Screenshot</h2>
            <img src="full_app_screenshot.png" alt="Full Application Screenshot">
          </div>` : ''}
          <div class="section">
            <h2>Whiteboard Elements Data</h2>
            <p>Raw data of whiteboard elements is included in <code>whiteboard_elements.json</code>.</p>
          </div>
          <div class="section">
            <h2>Prompt Cards</h2>
            <p>A history of Gemini interactions (prompts and responses) from this session is included in the <code>prompt_cards/</code> directory as individual Markdown files.</p>
          </div>
          <div class="section">
            <h2>Application Metadata</h2>
            <p>Application metadata is included in <code>application_metadata.json</code>.</p>
            <p>ViewBox State at Save: X=${viewBoxX.toFixed(2)}, Y=${viewBoxY.toFixed(2)}</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const zip = new JSZip();
    zip.file("model_card.html", modelCardHTML);
    zip.file("canvas_image.png", imageBase64, { base64: true });
    if (fullAppScreenshotBase64) {
      zip.file("full_app_screenshot.png", fullAppScreenshotBase64, { base64: true });
    }
    zip.file("whiteboard_elements.json", JSON.stringify(elements, null, 2));
    
    const appMetadata = {
      name: "Co-Creation Canvas Session",
      version: "1.0", 
      sessionName: sessionName || DEFAULT_SESSION_NAME,
      savedAt: new Date().toISOString(),
      canvasRenderWidth,
      canvasRenderHeight,
      viewBoxX,
      viewBoxY,
      elementCount: elements.length
    };
    zip.file("application_metadata.json", JSON.stringify(appMetadata, null, 2));

    const promptCardsFolder = zip.folder("prompt_cards");
    if (promptCardsFolder) {
        elements.forEach(element => {
            if (element.type === 'content-box' && element.filename?.startsWith('Gemini_Response_')) {
                promptCardsFolder.file(element.filename, element.content);
            }
        });
    }


    try {
      const zipBlob = await zip.generateAsync({ type: "blob" });
      const link = document.createElement('a');
      link.download = generateSafeFilename(`${sessionName || DEFAULT_SESSION_NAME}_ModelCard`, 'zip');
      link.href = URL.createObjectURL(zipBlob);
      link.click();
      URL.revokeObjectURL(link.href);
    } catch (err) {
      console.error("Error generating ZIP for model card:", err);
      alert("Failed to generate Model Card ZIP file.");
    } finally {
      setIsModelCardGenerating(false);
    }
  }, [getCanvasImageBase64, getFullAppScreenshotBase64, elements, canvasRenderWidth, canvasRenderHeight, sessionName, viewBoxX, viewBoxY]);


  const saveBriefcaseAsZip = useCallback(async () => {
    setIsBriefcaseSaving(true);
    const zip = new JSZip();
    const briefcaseFolder = zip.folder("briefcase");

    if (!briefcaseFolder) {
        alert("Failed to create briefcase folder in ZIP.");
        setIsBriefcaseSaving(false);
        return;
    }
    
    const briefcaseFiles: Record<string, string> = {
        "README.md": `# Project Briefcase

This directory serves as a "briefcase" to maintain persistent context, track progress, and outline the core concept and features for the Co-Creation Canvas application. It's designed to aid continuity in development, especially across sessions or if conversational context is limited.

## Contents:

1.  **\`README.md\`** (this file): 
    *   Explains the purpose and contents of the briefcase directory.
2.  **\`CONCEPT_PLAN.md\`**:
    *   Outlines the application's vision, core architecture, key implemented features, planned/potential future features, and guiding design philosophies. This document provides a long-term strategic overview.
3.  **\`PROGRESS_LOG.md\`**:
    *   Serves as a more dynamic, running journal of development. It includes the last major milestone, current focus, recent achievements, known issues, and potential next steps. This helps in quickly resuming work and understanding the immediate state of the project.
4.  **\`AI_COLLABORATION_MODEL.md\`**:
    *   Defines the interaction model between the user and the AI, including communication protocols and thinking frameworks.
5.  **\`BRIEFCASE_DIGEST.json\`**:
    *   A JSON file that aggregates the content of the other four markdown files (\`README.md\`, \`CONCEPT_PLAN.md\`, \`PROGRESS_LOG.md\`, \`AI_COLLABORATION_MODEL.md\`) for easy programmatic parsing and context ingestion by the AI.
## Usage Protocol:

### Briefcase Digest
At the beginning of a new session (or when context needs refreshing), the user will provide the AI with the content of \`BRIEFCASE_DIGEST.json\` or the full content of \`briefcase/PROGRESS_LOG.md\` and, if relevant, key excerpts or a summary of \`briefcase/CONCEPT_PLAN.md\`. This \"digest\" helps prime the AI's context for the session.

### Suggesting Updates
The AI can be asked to suggest updates to these documents (e.g., drafting new entries for planned features or logging completed work). The user will then manually apply these suggestions to the files.

These documents are intended to be updated as the project evolves.`,
        "CONCEPT_PLAN.md": `# Co-Creation Canvas: Concept Plan

## 1. Application Vision
A modular, AI-assisted collaborative whiteboard designed for intuitive drawing, diagramming, text handling, and intelligent content generation/analysis via Google Gemini. The focus is on a custom-built, extensible platform where features are implemented directly for learning, fine-grained control, and a unique user experience.

## 2. Core Architecture
-   **Frontend Framework:** React with TypeScript.
-   **UI Management:** React components for toolbar, modals, interactive elements.
-   **State Management:** Custom React hooks for modular functionality:
    -   \`useToolManager\`: Manages active tool, colors, stroke widths, fill options, emoji selection, line style (arrow/plain/dotted).
    -   \`useElementManager\`: Manages all whiteboard elements (paths, shapes, text, images, connectors, content boxes), selection state, image object loading, and session name.
    -   \`useCanvasView\`: Manages canvas panning (viewBox) and coordinate transformations (virtual to viewport and vice-versa).
    -   \`useTextEditing\`: Manages state for inline text input overlay (primarily for shape text, less so for new text creation which uses ContentBoxEditorModal).
    -   \`useInteractionManager\`: Handles all mouse/touch events on the canvas for drawing, selection, moving, resizing, panning, connector snapping logic, and AI summary button interactions.
    -   \`useGemini\`: Manages interaction with Google Gemini (modals, prompts, processing responses, applying drawing commands, AI persona, per-element AI summaries).
    -   \`useFileOperations\`: Handles image/text file import, saving canvas as image, generating and saving model cards (including full app screenshots), and saving the project briefcase.
    -   \`useMermaid\`: Manages Mermaid diagram input and rendering to canvas.
-   **Rendering:** Direct HTML5 Canvas API for drawing all visual elements, orchestrated by React state changes and redraw cycles.
-   **Utilities:** Helper functions for geometry calculations (\`geometryUtils.ts\`), color manipulation (\`colorUtils.ts\`), and canvas drawing primitives (\`canvasUtils.ts\`).
-   **External Libraries:**
    -   \`@google/genai\`: For interacting with the Google Gemini API.
    -   \`JSZip\`: For creating ZIP archives for the "Save Model Card" and "Save Briefcase" features.
    -   \`html2canvas\`: For capturing full application screenshots.
    -   \`Mermaid\`: For rendering Mermaid syntax diagrams to SVG.

## 3. Key Implemented Features
-   **Drawing Tools:** Pencil, Eraser, various Flowchart Shapes (Rectangle, Oval, Diamond, Triangle, Parallelogram, Hexagon, Cylinder, Cloud, Star), Arrow/Line (Connector), Emoji Stamp.
-   **Text Handling:**
    -   User-created text (via TEXT tool) creates \`ContentBoxElement\` (supports word wrap, defined dimensions, background/text color, modal editing).
    -   Gemini-generated text also creates \`ContentBoxElement\`.
    -   Imported text files (TXT, MD, JS, PY, HTML, CSS, JSON) create \`ContentBoxElement\`. These support connector handles and automatic AI summary generation.
    -   Text input within Flowchart Shapes (uses \`TextInputOverlay\`).
-   **Element Manipulation:** Select, Move, Resize (for shapes, images, emojis, content boxes).
-   **Connectors:**
    -   Can be drawn as an arrow (solid line with arrowhead), a plain line (solid line, no arrowhead), or a dotted line (dotted pattern, no arrowhead). This is selectable via a toggle button in the Toolbar that appears when the \"Arrow/Line\" tool is active.
    -   Visual Connector Handles displayed on selected shapes, content boxes, and images (including Mermaid charts and imported images/text content boxes). Emojis are excluded.
    -   Interactive creation of connectors by dragging from these handles.
    -   Connector Snap Targeting: While drawing an arrow/line, potential snap points on other eligible elements are visually highlighted, and the end snaps to these points on mouse release.
    -   Sticky Connectors: Connectors remain attached to elements when those elements are moved.
    -   Drag-to-Detach: Dragging a connector line itself detaches it from elements.
-   **Import Functionality:**
    -   Images (PNG, JPG, JPEG, GIF, WEBP, SVG) - these now support connector handles and automatic AI summaries.
    -   Text files (TXT, MD, JS, PY, HTML, CSS, JSON) are imported into \`ContentBoxElement\`s - these support connector handles and automatic AI summary generation (including for \`.py\` files).
-   **Mermaid Diagram Integration:** Modal to input Mermaid syntax, which is then rendered as an image (which supports connector handles and automatic AI summaries) onto the canvas.
-   **Google Gemini AI Integration:**
    -   Analyze whiteboard content (generates a textual summary of the entire board).
    -   Interact with Gemini (via modal) to request drawings, modifications, or get ideas.
    -   Gemini system prompt enhanced with a detailed \`MENU_OPTIONS_JSON\` including \`uiPath\`, \`shortcutHint\` for tools/actions, and command schemas, providing better contextual \"augmented reality\" understanding of the application's capabilities (including the \`lineStyle\` options: 'arrow', 'plain', 'dotted' for connectors).
    -   AI Persona selection (Helpful Assistant, Mindless Robot, Architect, Artist, Creative Designer) to tailor Gemini's behavior and system instructions.
    -   **Google Search Grounding:** Gemini can leverage Google Search for responses, and any web sources used are displayed in the UI.
    -   **Per-Element AI Summaries (Phase 1 & 2 Complete):**
        -   Ability to associate AI-generated summaries with individual elements (shapes, images, text boxes, etc., excluding connectors).
        -   Includes properties in element types (\`aiSummary\`, \`aiSummaryVisible\`, \`aiSummaryLoading\`).
        -   UI elements drawn on canvas for selected elements: action buttons for \"Regenerate Summary\", \"Show/Hide Summary\", loading indicator, and the summary text box.
        -   Integrated Gemini calls to generate summaries for individual elements using text-based descriptions or image data for \`ImageElement\`s (multimodal).
        -   **Automatic Summary Generation:** Summaries are now automatically generated (asynchronously) when new elements (shapes, images, text boxes, emojis) are created. Summaries are initially hidden.
-   **Session Management:** Editable session name reflected in saved files.
-   **Export/Save Options:**
    -   \"Save Image\": Saves the entire canvas content (including off-screen elements by rendering to a temporary canvas) as a PNG file.
    -   \"Save Model Card\": Generates a ZIP file containing:
        -   \`model_card.html\` (summary, embedded canvas image link, embedded full app screen capture link, Gemini analysis text).
        -   The canvas content image (PNG).
        -   A full application screen capture image (PNG).
        -   Whiteboard elements data (JSON).
        -   Application metadata (JSON).
        -   Dynamic internal filenames within the ZIP archive based on session name and date.
    -   \"Save Briefcase\": Generates a ZIP file containing the project's contextual documents (\`README.md\`, \`CONCEPT_PLAN.md\`, \`PROGRESS_LOG.md\`, \`AI_COLLABORATION_MODEL.md\`, and \`BRIEFCASE_DIGEST.json\`).
-   **User Interface:**
    -   Toolbar for selecting tools, colors, stroke widths, line styles (for connectors), and actions. The \"Tools\" dropdown has a single \"Arrow/Line\" entry for connectors; the specific style (arrow, plain, dotted) is chosen via a secondary toggle.
    -   Draggable Modals for various interactions (Gemini, Mermaid, Content Box Editor).
    -   Pan tool and functionality.

## 4. Planned / Potential Future Features (Backlog Ideas)
-   **Per-Element AI Summaries (Phase 3 - UI/UX Refinements):** Finalize UI/UX for summary display and interaction, considering edge cases and user feedback.
-   **Connectors (Phase 2 Continued):**
    -   Update connector endpoints when connected elements are resized (currently only works for move).
    -   More connector styling options (e.g., different arrowheads if applicable, more dash patterns).
-   **Canvas Navigation:**
    -   Zoom functionality (zoom in/out, zoom to fit).
-   **Core Functionality:**
    -   Robust Undo/Redo system for element creation, deletion, and modifications.
    -   Grouping/Ungrouping of elements.
    -   Copy/Paste elements.
    -   Layers for organizing content.
-   **Text & Content Enhancement:**
    -   Richer text editing options for \`ContentBoxElement\` (e.g., bold, italics, lists, font selection within the modal or potentially inline).
-   **New Element Types:**
    -   Chart elements (Pie, Bar): User input for data, Gemini generation, rendering on canvas.
    -   Sticky notes.
-   **Advanced Gemini Commands:**
    -   \"Connect these two shapes with a dotted line.\"\n    -   \"Arrange these items neatly.\"\n    -   \"Summarize the text in this box.\" (Should use the per-element summary system)
-   **Persistence & Collaboration:**
    -   Local storage persistence for whiteboard sessions.
    -   (Long-term) Real-time collaboration (would require significant architectural changes, e.g., CRDTs, backend services).
-   **UI/UX Refinements:**
    -   Customizable shape properties (e.g., more colors, line styles via a properties panel).
    -   Snapping elements to a grid or to each other during move/resize.
    -   Improved accessibility (ARIA attributes, keyboard navigation).

## 5. Design Philosophies
-   **Modularity & Extensibility:** Core functionality is broken down into manageable, reusable custom hooks and utility functions to ensure the codebase is maintainable and easy to extend.
-   **Direct Implementation Focus:** Preferring custom implementation for core whiteboard features to maximize learning, control, and avoid unnecessary dependencies. Established libraries are used for specialized, well-defined tasks (AI API, ZIP archiving, SVG diagram rendering, full-page screenshots).
-   **User-Centric Design:** Striving for an intuitive, responsive, and accessible user interface. Features should be easy to discover and use.
-   **Performance:** Being mindful of rendering performance, especially as the number of elements on the canvas grows. Optimize drawing logic and state updates.
-   **AI as an Intelligent Assistant:** Leveraging Google Gemini to genuinely enhance creativity, productivity, and analytical capabilities on the whiteboard, rather than just being a novelty feature. The AI should understand the context of the application's tools and capabilities.
-   **Iterative Development:** Building features incrementally, testing, and refining based on feedback and observed behavior.
-   **Briefcase for Context:** Utilizing a \`briefcase\` directory with planning and logging documents to maintain persistent project context for AI-human collaboration.`,
        "PROGRESS_LOG.md": `# Co-Creation Canvas: Progress Log

## Project Inception Date (Approximate)
Early June 2024

## Last Major Milestone / Current State
*(As of 2024-06-15)*
-   **Application Renamed:** The application is now \"Co-Creation Canvas\". Updated relevant files.
-   **\"Save Model Card\" Augmentation with Prompt Cards:** Successfully enhanced the \"Save Model Card\" feature to include a \`prompt_cards\` subdirectory within the ZIP archive. Each \`ContentBoxElement\` on the whiteboard that was generated from a Gemini response (identified by its filename starting with \`Gemini_Response_\`) is now saved as an individual Markdown file in this subdirectory. The \`model_card.html\` has also been updated to mention this new addition.
-   **Google Search Grounding Integration:** Implemented functionality for Gemini to use Google Search for grounding its responses. Web sources (URLs and titles) used by Gemini are now displayed in the Gemini interaction and analysis modals.
-   **Per-Element AI Summaries (Phase 1 & 2 - Functionality Complete):**
    -   Added \`aiSummary\`, \`aiSummaryVisible\`, and \`aiSummaryLoading\` optional properties to all relevant element types.
    -   Implemented UI for displaying action buttons (\"Regenerate Summary\", \"Show/Hide Summary\", loading icon) and the summary text box itself on selected elements.
    -   Integrated Gemini calls (text-based for most elements, multimodal for \`ImageElement\`s) to generate summaries.
    -   Implemented click handlers in \`useInteractionManager\` for these action buttons to trigger summary generation/regeneration and toggle visibility.
    -   **Automatic Summary Generation:** Summaries are now automatically generated (asynchronously and initially hidden) when new elements (shapes, images, text boxes, emojis) are created.
-   **Extended Connector Handle Functionality:** Connector handles are displayed and interactive for \`ImageElement\`s and \`ContentBoxElement\`s.
-   **Save Briefcase Functionality:** Feature to download the \`briefcase/\` directory (including \`BRIEFCASE_DIGEST.json\`) as a ZIP archive.
-   **Python File Auto-Summary Fix:** Ensured that imported \`.py\` files correctly trigger automatic AI summary generation.

## Current Focus
-   **Sticky Connectors (Phase 1b - On Element Resize):**
    -   Investigate and implement logic to ensure that when an element (shape, image, content box) is resized, any connectors attached to it update their start/end points appropriately to maintain the connection at the correct attachment handle.

## Recent Achievements (Summary of last ~14 major feature updates/fixes)
1.  **Application Renamed to Co-Creation Canvas:** Updated files to reflect the new name. (June 15).
2.  **\"Save Model Card\" Augmentation with Prompt Cards:** Successfully augmented the \"Save Model Card\" ZIP to include Gemini response text boxes as individual Markdown files in a \`prompt_cards\` subdirectory. (June 15).
3.  **Google Search Grounding Display:** Enabled Gemini to use Google Search and display source URLs in the UI. (June 15).
4.  **Python File Auto-Summary Fix:** Confirmed and ensured that automatic AI summary generation functions correctly for imported \`.py\` files, leveraging explicit checks in \`useFileOperations.ts\`. (June 15).
5.  **Automatic Per-Element Summary Generation:** Summaries are now automatically generated (asynchronously and initially hidden) when new elements (shapes, images, text boxes, emojis) are created. (June 15).
6.  **Per-Element AI Summaries (Phase 2 - Gemini Integration & Interactivity):** Implemented Gemini calls for individual summaries (including multimodal for images), interactive \"Regenerate Summary\" and \"Show/Hide Summary\" buttons. (June 15).
7.  **Corrected \`geminiService.ts\` initialization:** Resolved path traversal and missing initializer errors by ensuring correct API key usage and module structure. (June 14)
8.  **Save Briefcase as ZIP:** Implemented functionality to download the \`briefcase/\` directory contents (including \`BRIEFCASE_DIGEST.json\`) as a ZIP file from the toolbar. (June 14).
9.  **Per-Element AI Summaries (Phase 1):** Data model and initial UI rendering (action buttons, text box) for AI summaries on elements. (June 14).
10. **Connector Handles Extended:** Connector handles are now displayed on and interactive for \`ImageElement\`s and \`ContentBoxElement\`s. (June 14).
11. **Dotted Line Style & Toolbar Menu Correction:** Added dotted line option for connectors. Toolbar menu for \"Arrow/Line\" tool corrected to a single entry, with style (arrow/plain/dotted) selected via a 3-state toggle. (June 14).
12. **Plain Line Style for Connectors:** Implemented a toggle in the Toolbar (for Arrow/Line tool) to switch between drawing lines with arrowheads or plain lines. (June 14).
13. **Connector Stickiness V11 Debugging Complete:** Addressed issues with connector origin points not sticking, lines detaching unexpectedly, and implemented intentional detachment when a connector line itself is dragged. (June 14).
14. **Reinstated V8-style logic for \`newMovedElementState\` (V10):** In \`useInteractionManager.ts\`, reverted the calculation of \`newMovedElementState\` to be based on its state at the absolute start of the drag for non-positional properties. (June 14).


## Identified Bugs/Issues (High-Level)
-   **Undo/Redo:** Full undo/redo stack for all actions is a major missing feature.
-   **Sticky Connectors on Element Resize:** Connectors currently only stick during element *move*, not resize. (Current Focus to address this).
-   **Manual Re-attachment of Free-Floating Connectors:** While lines detach when dragged, re-attaching their endpoints by dragging the connector's start/end points to snap targets on shapes is not fully implemented.
-   **Increased API Calls:** Automatic summary generation for each new element will increase API usage. Consider strategies if this becomes problematic (e.g., user toggle, batching, debouncing if elements are created very rapidly). Google Search grounding might also increase token usage or perceived latency.
-   **Gemini Drawing Precision:** Ongoing refinement may be needed for complex drawing requests, especially when search results might influence drawing instructions.
-   **Performance with Very Large Canvases:** Optimizations might be needed for an extremely high number of elements.
-   **Mermaid Rendering Timeouts:** More dynamic handling or user feedback for complex Mermaid diagrams.
-   **Text Editing UX:** \`ContentBoxEditorModal\` is functional; \`TextInputOverlay\` for shapes is basic.

## Potential Next Steps / Backlog (High-Level - Refer to \`CONCEPT_PLAN.md\` for a more exhaustive list)
1.  **Sticky Connectors (Phase 1b - On Element Resize):** Make connectors update their endpoints when connected elements are resized. (Current Focus).
2.  **Canvas Zoom Functionality:** Implement zoom in/out for the whiteboard.
3.  **Undo/Redo System:** Implement a robust undo/redo mechanism.
4.  **Richer Text Editing for \`ContentBoxElement\`s:** Explore options like simple formatting (bold, italics, lists) within the modal.
5.  **Manual Re-attachment of Connector Endpoints:** Allow users to drag the start/end points of a free-floating connector and have them snap to handles on shapes.
6.  **Per-Element AI Summaries (Phase 3 - UI/UX Refinements):** Finalize UI/UX for summary display and interaction.`,
        "AI_COLLABORATION_MODEL.md": `# AI Collaboration Model: Co-Creation Canvas Project

## 1. Core Purpose of AI Companion

This AI (Gemini) serves as an **AI companion for deep, co-creative discussions with intellectual integrity**, specifically applied to the development and refinement of the "Co-Creation Canvas" application. The goal is to foster a partnership that aids in conceptualisation, problem-solving, and iterative development.

## 2. Guiding Principles for Interaction

Our collaboration will be guided by the following principles:

*   **Critical Engagement:** The AI will constructively challenge ideas, question assumptions, and offer counterpoints to ensure robust solutions. Empty agreement will be avoided.
*   **Iterative Refinement:** The AI will support the ongoing development of ideas through structured feedback and analysis.
*   **Validation and Expansion:** Useful insights will be acknowledged, and the AI will aim to provide additional dimensions or perspectives.
*   **Intellectual Integrity:** The AI will strive for accuracy, honesty (including acknowledging limitations), and sound reasoning in all interactions.
*   **Depth and Rigour:** Discussions will prioritise in-depth analysis and sound reasoning over superficial summaries or speculation.

## 3. AI Persona and Preferences

*   **Language:** British English.
*   **Tone:** Measured, objective, and without hyperbole.
*   **Format:** Responses will aim to be direct, structured, and prioritise clarity.

## 4. Thinking Frameworks Employed by AI

The AI will leverage the following conceptual approaches:

*   **Paradigm Disruption:** Exploring unconventional perspectives.
*   **Conceptual Synthesis:** Connecting disparate ideas into coherent models.
*   **Meta-Cognition:** Reflecting on its own reasoning processes and engaging in structured inquiry (e.g., reviewing these guidelines).
*   **Logical Rigour:** Prioritising sound reasoning.

## 5. Engagement Approach

*   Encourage bold intellectual exploration grounded in rigorous reasoning.
*   Analyse core concepts deeply.
*   Question underlying assumptions to strengthen theories and designs.

## 6. "Project Briefcase" Protocol

To maintain context and continuity, especially across sessions:

*   **Core Documents:**
    *   \`CONCEPT_PLAN.md\`: Long-term strategic overview of the "Co-Creation Canvas."
    *   \`PROGRESS_LOG.md\`: Dynamic journal of development, current focus, achievements, issues, and next steps.
    *   \`AI_COLLABORATION_MODEL.md\` (this document): Outlines our agreed-upon interaction model.
*   **"Briefcase Digest" Usage:**
    *   At the beginning of new sessions or when context needs refreshing, the user will provide the AI with:
        *   The **full content of \`PROGRESS_LOG.md\`**.
        *   **Relevant excerpts or a summary of \`CONCEPT_PLAN.md\`** as pertinent to the session's goals.
        *   **Relevant excerpts from this \`AI_COLLABORATION_MODEL.md\`** if a specific reminder or emphasis on our interaction style is beneficial for the session.
*   **Document Updates:** The AI can assist in drafting updates or new entries for these documents. The user will manually apply these suggestions to the files within their AI Studio environment.

## 7. Tool Usage and Information Grounding

*   The AI will use provided tools (e.g., search, code execution) as appropriate to gather information or fulfil requests.
*   External information or tool outputs will be cited clearly.
*   The AI will acknowledge limitations in accessing certain types of information (e.g., private URLs, real-time data beyond its last update).

## 8. Objective

The consistent application of these guidelines aims to create a productive, insightful, and reliable collaborative environment for the successful development of the "Co-Creation Canvas." This document serves as a shared understanding to facilitate that goal.`
    };

    const digestContent = {
      readme_content: briefcaseFiles["README.md"],
      progress_log_content: briefcaseFiles["PROGRESS_LOG.md"],
      concept_plan_content: briefcaseFiles["CONCEPT_PLAN.md"],
      ai_collaboration_model_content: briefcaseFiles["AI_COLLABORATION_MODEL.md"],
    };
    briefcaseFiles["BRIEFCASE_DIGEST.json"] = JSON.stringify(digestContent, null, 2);

    for (const [fileName, content] of Object.entries(briefcaseFiles)) {
        briefcaseFolder.file(fileName, content);
    }

    const promptCardsFolder = briefcaseFolder.folder("prompt_cards");
    if (promptCardsFolder) {
        elements.forEach(element => {
            if (element.type === 'content-box' && element.filename?.startsWith('Gemini_Response_')) {
                promptCardsFolder.file(element.filename, element.content);
            }
        });
    }


    try {
      const zipBlob = await zip.generateAsync({ type: "blob" });
      const link = document.createElement('a');
      link.download = generateSafeFilename("Whiteboard_Briefcase", 'zip');
      link.href = URL.createObjectURL(zipBlob);
      link.click();
      URL.revokeObjectURL(link.href);
    } catch (err) {
      console.error("Error generating ZIP for briefcase:", err);
      alert("Failed to generate Briefcase ZIP file.");
    } finally {
      setIsBriefcaseSaving(false);
    }
  }, [elements, sessionName]);


  const triggerImageImport = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = ""; 
      fileInputRef.current.click();
    }
  };

  const handleFileSelected = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const fileNameLower = file.name.toLowerCase();
    const reader = new FileReader();

    if (fileNameLower.endsWith(SESSION_FILE_EXTENSION)) {
        reader.onload = (e) => {
            try {
                const textContent = e.target?.result as string;
                if (!textContent) {
                    alert("Failed to read session file content.");
                    return;
                }
                const sessionData = JSON.parse(textContent);

                // Basic validation
                if (sessionData && sessionData.version && sessionData.sessionName && Array.isArray(sessionData.elements) && sessionData.viewBox && typeof sessionData.viewBox.x === 'number' && typeof sessionData.viewBox.y === 'number' && typeof sessionData.aiPersona === 'string') {
                    clearCanvasElements(); // Clear existing elements and selectedId
                    setElements(sessionData.elements); // Load elements first
                    onSessionNameChange(sessionData.sessionName);
                    setViewBox(sessionData.viewBox.x, sessionData.viewBox.y);
                    if (geminiHook && geminiHook.setCurrentAiPersona) {
                       geminiHook.setCurrentAiPersona(sessionData.aiPersona as AiPersona);
                    }
                    setCurrentTool(Tool.SELECT);
                    // Image elements will be reloaded via useEffect in useElementManager
                    // Element summaries are part of element data and will be restored
                } else {
                    alert("Invalid session file format. Essential data is missing.");
                }
            } catch (error) {
                console.error("Error loading session file:", error);
                alert("Failed to load session file. It might be corrupted or not a valid session file.");
            }
        };
        reader.readAsText(file);
    } else if (Object.keys(SUPPORTED_TEXT_IMPORT_EXTENSIONS).some(ext => fileNameLower.endsWith(ext))) {
        const fileExtension = '.' + fileNameLower.split('.').pop();
        const contentType = SUPPORTED_TEXT_IMPORT_EXTENSIONS[fileExtension!]; // Assertion: pop() will not be undefined if some() was true
        
        reader.onload = (e) => {
            const textContent = e.target?.result as string;
            const newContentBox: ContentBoxElement = {
              id: `imported-text-${Date.now()}`,
              type: 'content-box',
              x: viewBoxX + 50,
              y: viewBoxY + 50,
              width: DEFAULT_CONTENT_BOX_WIDTH,
              height: DEFAULT_CONTENT_BOX_HEIGHT,
              contentType: contentType,
              filename: file.name,
              content: textContent,
              backgroundColor: DEFAULT_CONTENT_BOX_BACKGROUND_COLOR,
              textColor: DEFAULT_CONTENT_BOX_TEXT_COLOR,
              fontSize: DEFAULT_CONTENT_BOX_FONT_SIZE,
            };
            addElement(newContentBox);
            setSelectedElementId(newContentBox.id);
            setCurrentTool(Tool.SELECT);
            if (geminiHook && geminiHook.triggerAutomaticSummaryGeneration) {
              geminiHook.triggerAutomaticSummaryGeneration(newContentBox);
            }
          };
          reader.readAsText(file);
    } else if (['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'].some(ext => fileNameLower.endsWith(ext))) {
        reader.onload = (e) => {
            const dataUrl = e.target?.result as string;
            const img = new Image();
            img.onload = () => {
              const newImageElement: ImageElement = {
                id: `imported-image-${Date.now()}`,
                type: 'image',
                src: dataUrl,
                x: viewBoxX + 50,
                y: viewBoxY + 50,
                width: img.naturalWidth > 300 ? 300 : img.naturalWidth,
                height: img.naturalWidth > 300 ? (img.naturalHeight * (300 / img.naturalWidth)) : img.naturalHeight,
                naturalWidth: img.naturalWidth,
                naturalHeight: img.naturalHeight,
              };
              addElement(newImageElement);
              setSelectedElementId(newImageElement.id);
              setCurrentTool(Tool.SELECT);
              if (geminiHook && geminiHook.triggerAutomaticSummaryGeneration) {
                geminiHook.triggerAutomaticSummaryGeneration(newImageElement);
              }
            };
            img.src = dataUrl;
        };
        reader.readAsDataURL(file);
    } else {
      alert(`Unsupported file type: ${file.name}`);
    }
  };

  const saveSession = useCallback(async () => {
    setIsSessionSaving(true);
    try {
      const sessionData = {
        version: "1.0.0",
        sessionName: elementManager.sessionName,
        elements: elementManager.elements,
        viewBox: {
          x: canvasView.viewBoxX,
          y: canvasView.viewBoxY,
        },
        aiPersona: geminiHook.currentAiPersona,
      };

      const sessionJSON = JSON.stringify(sessionData, null, 2);
      const blob = new Blob([sessionJSON], { type: 'application/json' });
      const link = document.createElement('a');
      link.download = generateSafeFilename(elementManager.sessionName || DEFAULT_SESSION_NAME, SESSION_FILE_EXTENSION);
      link.href = URL.createObjectURL(blob);
      link.click();
      URL.revokeObjectURL(link.href);
    } catch (error) {
      console.error("Error saving session:", error);
      alert("Failed to save session.");
    } finally {
      setIsSessionSaving(false);
    }
  }, [elementManager.sessionName, elementManager.elements, canvasView.viewBoxX, canvasView.viewBoxY, geminiHook.currentAiPersona]);


  return {
    saveCanvasAsImage,
    saveModelCard,
    saveBriefcaseAsZip,
    triggerImageImport,
    fileInputRef,
    handleFileSelected,
    acceptedFileTypes,
    isModelCardGenerating,
    isBriefcaseSaving,
    saveSession, 
    isSessionSaving, 
  };
};

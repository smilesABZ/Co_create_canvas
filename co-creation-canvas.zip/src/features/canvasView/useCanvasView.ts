// FILENAME: src/features/canvasView/useCanvasView.ts - VERSION: v1
import { useState, useCallback } from 'react';
import { Point } from '../../../types';

export interface CanvasViewHook {
  viewBoxX: number;
  viewBoxY: number;
  setViewBox: (x: number, y: number) => void;
  panCanvas: (deltaX: number, deltaY: number, panStartViewBox?: {x:number, y:number} | null) => void;
  toVirtualPos: (viewportPos: Point) => Point;
  toViewportPos: (virtualPos: Point) => Point;
  resetViewBox: () => void;
}

export const useCanvasView = (): CanvasViewHook => {
  const [viewBoxX, setViewBoxX] = useState<number>(0);
  const [viewBoxY, setViewBoxY] = useState<number>(0);

  const setViewBox = useCallback((x: number, y: number) => {
    setViewBoxX(x);
    setViewBoxY(y);
  }, []);

  const panCanvas = useCallback((deltaX: number, deltaY: number, panStartViewBox?: {x:number, y:number} | null) => {
      if (panStartViewBox) {
        setViewBoxX(panStartViewBox.x - deltaX);
        setViewBoxY(panStartViewBox.y - deltaY);
      } else {
        setViewBoxX(prevX => prevX - deltaX);
        setViewBoxY(prevY => prevY - deltaY);
      }
  }, []);

  const toVirtualPos = useCallback((viewportPos: Point): Point => {
    return { x: viewportPos.x + viewBoxX, y: viewportPos.y + viewBoxY };
  }, [viewBoxX, viewBoxY]);

  const toViewportPos = useCallback((virtualPos: Point): Point => {
    return { x: virtualPos.x - viewBoxX, y: virtualPos.y - viewBoxY };
  }, [viewBoxX, viewBoxY]);

  const resetViewBox = useCallback(() => {
    setViewBoxX(0);
    setViewBoxY(0);
  }, []);

  return {
    viewBoxX,
    viewBoxY,
    setViewBox,
    panCanvas,
    toVirtualPos,
    toViewportPos,
    resetViewBox,
  };
};
